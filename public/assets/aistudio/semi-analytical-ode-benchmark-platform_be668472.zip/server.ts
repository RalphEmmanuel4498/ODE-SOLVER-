import express from "express";
import path from "path";
import fs from "fs";
import { exec } from "child_process";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "20mb" }));

// Helper to execute Python command safely
function runPythonJson(commandCode: string): Promise<any> {
  return new Promise((resolve, reject) => {
    // Escape double quotes and backslashes for bash subshell execution
    const escaped = commandCode.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    exec(
      `python3 -c "${escaped}"`,
      { maxBuffer: 15 * 1024 * 1024, cwd: __dirname },
      (error, stdout, stderr) => {
        if (error) {
          console.error("Python execution error:", stderr || stdout);
          return reject(new Error(stderr || stdout || error.message));
        }
        try {
          const parsed = JSON.parse(stdout.trim());
          resolve(parsed);
        } catch (parseErr) {
          const lines = stdout.trim().split("\n");
          for (let i = lines.length - 1; i >= 0; i--) {
            try {
              const res = JSON.parse(lines[i]);
              return resolve(res);
            } catch (_) {}
          }
          reject(new Error(`Failed to parse Python JSON output: ${stdout.slice(0, 500)}`));
        }
      }
    );
  });
}

// ---------------------------------------------------------------------------
// 1. Benchmark Problems & Canonical Scientific Models
// ---------------------------------------------------------------------------
app.get("/api/problems", async (req, res) => {
  try {
    const code = `
import json
from semi_analytical_benchmark.problems import list_problems

probs = []
for p in list_problems():
    probs.append({
        "id": p.id,
        "name": p.name,
        "category": p.category,
        "equation_latex": p.equation_latex,
        "description": p.description,
        "order": p.order,
        "t_span": list(p.t_span),
        "initial_conditions": p.initial_conditions,
        "parameters": p.parameters,
        "has_exact_solution": p.has_exact_solution,
        "exact_solution_latex": p.exact_solution_latex,
        "stiff": p.stiff,
        "notes": p.notes
    })
print(json.dumps(probs))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/canonical-models", async (req, res) => {
  try {
    const code = `
import json
from semi_analytical_benchmark.equation_parser import list_canonical_models

models = list_canonical_models()
print(json.dumps(models))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/parse-equation", async (req, res) => {
  try {
    const { latexText = "", customParams = {} } = req.body;
    const sanitized = latexText.replace(/"/g, '\\"');
    const code = `
import json
from semi_analytical_benchmark.equation_parser import parse_mathematical_model

model = parse_mathematical_model("${sanitized}", custom_params=${JSON.stringify(customParams)})
print(json.dumps({
    "raw_latex": model.raw_latex,
    "problem_type": model.problem_type,
    "display_title": model.display_title,
    "independent_var": model.independent_var,
    "dependent_vars": model.dependent_vars,
    "parameters": model.parameters,
    "initial_conditions": model.initial_conditions,
    "equations_latex": model.equations_latex,
    "control_var": model.control_var,
    "objective_functional_latex": model.objective_functional_latex,
    "recommended_methods": model.recommended_methods,
    "conservation_laws": model.conservation_laws,
    "warnings": model.warnings
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 2. Semi-Analytical & Numerical Solvers
// ---------------------------------------------------------------------------
app.post("/api/run-method", async (req, res) => {
  try {
    const { problemId = "riccati_ivp", method = "HAM", order = 4, hbar = -1.0, cConstants = null } = req.body;
    const cParam = cConstants && Array.isArray(cConstants) ? JSON.stringify(cConstants) : "None";
    const code = `
import json
from semi_analytical_benchmark.experiments import run_single_experiment

result = run_single_experiment(
    problem_id="${problemId}",
    method_name="${method}",
    order=${parseInt(order, 10)},
    hbar=${parseFloat(hbar)},
    c_constants=${cParam}
)
print(json.dumps(result))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/hbar-curve", async (req, res) => {
  try {
    const { problemId = "riccati_ivp", order = 4, hbarMin = -2.0, hbarMax = 0.2, numPoints = 40 } = req.body;
    const code = `
import json
from semi_analytical_benchmark.problems import load_problem
from semi_analytical_benchmark.ham import compute_hbar_curve

prob = load_problem("${problemId}")
curve = compute_hbar_curve(
    prob,
    order=${parseInt(order, 10)},
    hbar_range=(${parseFloat(hbarMin)}, ${parseFloat(hbarMax)}),
    num_points=${parseInt(numPoints, 10)}
)
print(json.dumps(curve))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Step-by-Step Solver for single and coupled ODE systems
app.post("/api/step-by-step-solve", async (req, res) => {
  try {
    const {
      problemType = "coupled_predator_prey",
      method = "ADM",
      order = 3,
      parameters = {},
      initialConditions = {},
      tSpan = [0.0, 2.0]
    } = req.body;

    const code = `
import json
from semi_analytical_benchmark.step_by_step_engine import compute_step_by_step_solution

result = compute_step_by_step_solution(
    problem_type="${problemType}",
    method="${method}",
    order=${parseInt(order, 10)},
    parameters=${JSON.stringify(parameters)},
    initial_conditions=${JSON.stringify(initialConditions)},
    t_span=${JSON.stringify(tSpan)}
)
print(json.dumps(result))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Automatic Method Selection & Feasibility Recommendation Matrix
app.post("/api/recommend-methods", async (req, res) => {
  try {
    const {
      eqType = "Coupled First-Order ODE System",
      isCoupled = true,
      isNonlinear = true,
      isStiff = false,
      order = 1,
      hasSmallParameter = false,
      isOscillatory = false
    } = req.body;

    const code = `
import json
from semi_analytical_benchmark.step_by_step_engine import recommend_methods_for_system

result = recommend_methods_for_system(
    eq_type="${eqType}",
    is_coupled=${isCoupled ? "True" : "False"},
    is_nonlinear=${isNonlinear ? "True" : "False"},
    is_stiff=${isStiff ? "True" : "False"},
    order=${parseInt(order, 10)},
    has_small_parameter=${hasSmallParameter ? "True" : "False"},
    is_oscillatory=${isOscillatory ? "True" : "False"}
)
print(json.dumps(result))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Differential Transform Method (DTM) endpoint
app.post("/api/run-dtm", async (req, res) => {
  try {
    const { problemId = "riccati_ivp", order = 4 } = req.body;
    const code = `
import json
from semi_analytical_benchmark.problems import load_problem
from semi_analytical_benchmark.dtm import solve_dtm

prob = load_problem("${problemId}")
res = solve_dtm(prob, order=${parseInt(order, 10)})
print(json.dumps({
    "problem_id": res.problem_id,
    "order": res.order,
    "t_eval": res.t_eval.tolist(),
    "u_approx": res.u_approx.tolist(),
    "transform_coefficients": res.transform_coefficients,
    "series_latex": res.series_latex,
    "term_expressions": res.term_expressions,
    "wall_time_sec": res.wall_time_sec,
    "recurrence_relation_latex": res.recurrence_relation_latex
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Optimal Homotopy Asymptotic Method (OHAM) endpoint
app.post("/api/run-oham", async (req, res) => {
  try {
    const { problemId = "riccati_ivp", order = 2, cInitial = null } = req.body;
    const cParam = cInitial && Array.isArray(cInitial) ? JSON.stringify(cInitial) : "None";
    const code = `
import json
from semi_analytical_benchmark.problems import load_problem
from semi_analytical_benchmark.oham import solve_oham

prob = load_problem("${problemId}")
res = solve_oham(prob, order=${parseInt(order, 10)}, c_initial=${cParam})
print(json.dumps({
    "method": res.method,
    "problem_id": res.problem_id,
    "order": res.order,
    "c_constants": res.c_constants,
    "t_eval": res.t_eval.tolist(),
    "u_approx": res.u_approx.tolist(),
    "series_latex": res.series_latex,
    "term_expressions": res.term_expressions,
    "residual_norm": res.residual_norm,
    "wall_time_sec": res.wall_time_sec,
    "homotopy_formulation_latex": res.homotopy_formulation_latex,
    "optimization_method": res.optimization_method,
    "algorithmic_steps": res.algorithmic_steps,
    "metadata": res.metadata
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Padé Approximants endpoint
app.post("/api/run-pade", async (req, res) => {
  try {
    const { coefficients = [0, 1, 1, 0.333, -0.333], m = 2, n = 2, tSpan = [0.0, 2.0] } = req.body;
    const code = `
import json
import numpy as np
from semi_analytical_benchmark.pade import compute_pade_coefficients, evaluate_pade

t_eval = np.linspace(${tSpan[0]}, ${tSpan[1]}, 101)
p, q, latex_str = compute_pade_coefficients(${JSON.stringify(coefficients)}, ${parseInt(m, 10)}, ${parseInt(n, 10)})
u_pade = evaluate_pade(p, q, t_eval)

print(json.dumps({
    "p_coeffs": p,
    "q_coeffs": q,
    "latex": latex_str,
    "t_eval": t_eval.tolist(),
    "u_pade": u_pade.tolist()
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 3. Optimal Control & Optimization
// ---------------------------------------------------------------------------
app.post("/api/optimal-control", async (req, res) => {
  try {
    const {
      beta = 1.4,
      gamma = 0.4,
      B = 2.0,
      uMax = 0.8,
      T = 20.0,
      numPoints = 151
    } = req.body;

    const code = `
import json
from semi_analytical_benchmark.optimal_control import solve_optimal_control_sir

oc_res = solve_optimal_control_sir(
    beta=${parseFloat(beta)},
    gamma=${parseFloat(gamma)},
    B=${parseFloat(B)},
    u_max=${parseFloat(uMax)},
    T=${parseFloat(T)},
    num_points=${parseInt(numPoints, 10)}
)

print(json.dumps({
    "problem_title": oc_res.problem_title,
    "t_eval": oc_res.t_eval.tolist(),
    "state_names": oc_res.state_names,
    "controlled_states": {k: v.tolist() for k, v in oc_res.controlled_states.items()},
    "uncontrolled_states": {k: v.tolist() for k, v in oc_res.uncontrolled_states.items()},
    "optimal_control": oc_res.optimal_control.tolist(),
    "costates": {k: v.tolist() for k, v in oc_res.costates.items()},
    "hamiltonian_latex": oc_res.hamiltonian_latex,
    "adjoint_equations_latex": oc_res.adjoint_equations_latex,
    "optimality_condition_latex": oc_res.optimality_condition_latex,
    "cost_controlled": oc_res.cost_controlled,
    "cost_uncontrolled": oc_res.cost_uncontrolled,
    "cost_reduction_percent": oc_res.cost_reduction_percent,
    "iterations": oc_res.iterations,
    "converged": oc_res.converged,
    "status_message": oc_res.status_message
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 4. Sensitivity, Stability & Phase Plane Analysis
// ---------------------------------------------------------------------------
app.post("/api/stability-analysis", async (req, res) => {
  try {
    const { modelId = "sir_epidemic", beta = 1.2, gamma = 0.4, alpha = 1.1, delta = 0.1 } = req.body;
    let pyFunc = `analyze_sir_system(beta=${parseFloat(beta)}, gamma=${parseFloat(gamma)})`;
    if (modelId === "lotka_volterra") {
      pyFunc = `analyze_lotka_volterra_system(alpha=${parseFloat(alpha)}, beta=${parseFloat(beta)}, gamma=${parseFloat(gamma)}, delta=${parseFloat(delta)})`;
    }

    const code = `
import json
from semi_analytical_benchmark.dynamical_analysis import analyze_sir_system, analyze_lotka_volterra_system

rep = ${pyFunc}
eqs = []
for eq in rep.equilibria:
    eqs.append({
        "coordinates": eq.coordinates,
        "jacobian": eq.jacobian,
        "eigenvalues": eq.eigenvalues,
        "classification": eq.classification,
        "is_stable": eq.is_stable,
        "notes": eq.notes
    })

sens = []
for s in rep.sensitivity_ranking:
    sens.append({
        "parameter_name": s.parameter_name,
        "target_variable": s.target_variable,
        "sensitivity_index": s.sensitivity_index,
        "interpretation": s.interpretation
    })

print(json.dumps({
    "model_id": rep.model_id,
    "model_title": rep.model_title,
    "equilibria": eqs,
    "r0_value": rep.r0_value,
    "r0_formula_latex": rep.r0_formula_latex,
    "sensitivity_ranking": sens,
    "vector_field_grid": rep.vector_field_grid
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 5. Model Calibration & Parameter Estimation
// ---------------------------------------------------------------------------
app.post("/api/calibrate-model", async (req, res) => {
  try {
    const { tData, yData, modelType = "logistic" } = req.body;
    const tArr = tData || [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    const yArr = yData || [0.5, 0.85, 1.35, 1.78, 1.94, 1.98, 1.99, 2.0, 2.0, 2.0, 2.0];

    const code = `
import json
import numpy as np
from semi_analytical_benchmark.model_calibration import calibrate_logistic_growth

t_vec = np.array(${JSON.stringify(tArr)}, dtype=np.float64)
y_vec = np.array(${JSON.stringify(yArr)}, dtype=np.float64)

cal_res = calibrate_logistic_growth(t_vec, y_vec)
print(json.dumps({
    "model_name": cal_res.model_name,
    "target_variable": cal_res.target_variable,
    "parameter_estimates": cal_res.parameter_estimates,
    "standard_errors": cal_res.standard_errors,
    "confidence_intervals_95": cal_res.confidence_intervals_95,
    "r_squared": cal_res.r_squared,
    "rss": cal_res.rss,
    "rmse": cal_res.rmse,
    "aic": cal_res.aic,
    "bic": cal_res.bic,
    "t_observed": cal_res.t_observed,
    "y_observed": cal_res.y_observed,
    "y_fitted": cal_res.y_fitted,
    "residuals": cal_res.residuals,
    "converged": cal_res.converged,
    "status_message": cal_res.status_message
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 6. Research Literature Discovery (OpenAlex, Crossref, Google Scholar linkouts)
// ---------------------------------------------------------------------------
app.get("/api/search-literature", async (req, res) => {
  try {
    const query = req.query.q as string || "homotopy analysis method nonlinear ODE";
    const code = `
import json
from semi_analytical_benchmark.literature_discovery import get_curated_literature_discovery

ans = get_curated_literature_discovery("${query.replace(/"/g, '\\"')}")
print(json.dumps(ans))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 7. Research Datasets Discovery (Zenodo & Curated Empirical Data)
// ---------------------------------------------------------------------------
app.get("/api/search-datasets", async (req, res) => {
  try {
    const query = req.query.q as string || "differential equation model";
    const code = `
import json
from semi_analytical_benchmark.dataset_discovery import search_zenodo, CURATED_DATASETS

zenodo_items = search_zenodo("${query.replace(/"/g, '\\"')}", max_results=5)
print(json.dumps({
    "query": "${query.replace(/"/g, '\\"')}",
    "curated_datasets": CURATED_DATASETS,
    "zenodo_datasets": zenodo_items
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/inspect-csv", async (req, res) => {
  try {
    const { csvContent = "" } = req.body;
    const code = `
import json
from semi_analytical_benchmark.dataset_discovery import inspect_dataset_csv

analysis = inspect_dataset_csv('''${csvContent.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}''')
print(json.dumps(analysis))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 8. LaTeX Paper & Python Reproduction Generator
// ---------------------------------------------------------------------------
app.post("/api/generate-latex-paper", async (req, res) => {
  try {
    const { modelName = "Nonlinear Model", equations = [], parameters = {}, initialConditions = {}, methodResults = [] } = req.body;
    const code = `
import json
from semi_analytical_benchmark.latex_report_generator import generate_latex_paper, generate_python_reproduction_script

latex_src = generate_latex_paper(
    model_name="${modelName}",
    equations_latex=${JSON.stringify(equations)},
    parameters=${JSON.stringify(parameters)},
    initial_conditions=${JSON.stringify(initialConditions)},
    method_results=${JSON.stringify(methodResults)}
)

py_script = generate_python_reproduction_script(
    model_name="${modelName}",
    equations_latex=${JSON.stringify(equations)},
    parameters=${JSON.stringify(parameters)},
    initial_conditions=${JSON.stringify(initialConditions)}
)

print(json.dumps({
    "latex_source": latex_src,
    "python_script": py_script
}))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// 9. Existing Core Endpoints (Autonomy, Tests, Matrix, CSV, Adomian)
// ---------------------------------------------------------------------------
app.post("/api/autonomy-query", async (req, res) => {
  try {
    const { query = "What can this app do?" } = req.body;
    const sanitizedQuery = query.replace(/"/g, '\\"');
    const code = `
import json
from semi_analytical_benchmark.autonomy import query_autonomy

ans = query_autonomy("${sanitizedQuery}")
print(json.dumps(ans))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/adomian-polynomials", async (req, res) => {
  try {
    const nonlinearExpr = req.query.expr || "u**2";
    const numTerms = parseInt(req.query.numTerms as string || "6", 10);
    const code = `
import json
import sympy as sp
from semi_analytical_benchmark.adm import compute_adomian_polynomials

A_list = compute_adomian_polynomials("${nonlinearExpr}", ${numTerms})
result = {
    "nonlinear_operator": "${nonlinearExpr}",
    "adomian_polynomials": [sp.sstr(A) for A in A_list],
    "latex_polynomials": [sp.latex(A) for A in A_list]
}
print(json.dumps(result))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/run-tests", async (req, res) => {
  try {
    const code = `
import json
from semi_analytical_benchmark.validation import run_all_tests

report = run_all_tests()
print(json.dumps(report))
`;
    const data = await runPythonJson(code);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/benchmark-matrix", (req, res) => {
  const csvPath = path.resolve(__dirname, "results", "benchmark_results.csv");
  if (!fs.existsSync(csvPath)) {
    return res.status(404).json({ error: "Benchmark CSV not yet generated." });
  }
  try {
    const content = fs.readFileSync(csvPath, "utf-8");
    const lines = content.trim().split("\n");
    const headers = lines[0].split(",");
    const records = lines.slice(1).map((line) => {
      const vals = line.split(",");
      const obj: any = {};
      headers.forEach((h, idx) => {
        const val = vals[idx];
        if (val === "True" || val === "true") obj[h] = true;
        else if (val === "False" || val === "false") obj[h] = false;
        else if (val === "nan" || val === "NaN" || val === "") obj[h] = null;
        else if (!isNaN(Number(val))) obj[h] = Number(val);
        else obj[h] = val;
      });
      return obj;
    });
    res.json({ count: records.length, records });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/export-csv", (req, res) => {
  const csvPath = path.resolve(__dirname, "results", "benchmark_results.csv");
  if (fs.existsSync(csvPath)) {
    res.setHeader("Content-Disposition", "attachment; filename=benchmark_results.csv");
    res.setHeader("Content-Type", "text/csv");
    fs.createReadStream(csvPath).pipe(res);
  } else {
    res.status(404).send("CSV file not found.");
  }
});

app.get("/api/report", (req, res) => {
  const reportPath = path.resolve(__dirname, "technical_report.md");
  if (fs.existsSync(reportPath)) {
    res.setHeader("Content-Type", "text/markdown");
    res.send(fs.readFileSync(reportPath, "utf-8"));
  } else {
    res.status(404).send("Technical report not found.");
  }
});

// ---------------------------------------------------------------------------
// Vite Dev Server / Static Production Mounting
// ---------------------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
