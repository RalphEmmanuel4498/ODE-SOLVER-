/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Layers,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Sparkles,
  Search,
  Filter,
  Cpu,
  TrendingUp,
  Activity,
  Sliders,
  RotateCcw,
  Check,
  ChevronRight,
  ExternalLink
} from "lucide-react";
import { MathView } from "./MathView";

export interface MethodInfo {
  id: string;
  name: string;
  pioneerYear: string;
  category: "Analytical Exact" | "Semi-Analytical" | "Perturbation & Asymptotic" | "Series Acceleration" | "High-Order Numerical";
  tagline: string;
  formulaLatex: string;
  description: string;
  strengths: string[];
  limitations: string[];
  idealProblems: string[];
  convergenceParameters?: {
    name: string;
    symbol: string;
    role: string;
    guideline: string;
  }[];
  algorithmicSteps?: {
    step: string;
    name: string;
    description: string;
    latex?: string;
  }[];
}

export const METHODS_CATALOG: MethodInfo[] = [
  // -------------------------------------------------------------------------
  // 1. Exact Analytical Methods
  // -------------------------------------------------------------------------
  {
    id: "sep_vars",
    name: "Separation of Variables",
    pioneerYear: "Johann Bernoulli (1695)",
    category: "Analytical Exact",
    tagline: "Factorial algebraic separation of differentials for first-order ODEs and separable PDEs",
    formulaLatex: "\\int \\frac{dy}{g(y)} = \\int f(x) \\, dx + C",
    description: "The foundational analytical technique for differential equations whose algebraic structure allows dependent and independent differentials to be segregated entirely onto opposing sides.",
    strengths: ["Exact closed-form solution", "Zero truncation or roundoff error", "Global domain validity"],
    limitations: ["Strictly inapplicable to coupled multi-variable systems", "Requires antiderivative integrability of g(y)"],
    idealProblems: ["Autonomous population growth", "Newton's cooling law", "1D Heat/Wave PDEs via Fourier series"]
  },
  {
    id: "integrating_factor",
    name: "Integrating Factor Method",
    pioneerYear: "Leonhard Euler (1739)",
    category: "Analytical Exact",
    tagline: "Multiplier transforming first-order linear equations into exact total differentials",
    formulaLatex: "\\mu(t) = \\exp\\left(\\int P(t)\\,dt\\right) \\implies \\frac{d}{dt}[\\mu(t) y] = \\mu(t) Q(t)",
    description: "Multiplies a linear ordinary differential equation by an exponential integrating factor mu(t) such that the left-hand side collapses into the exact derivative of a product.",
    strengths: ["Exact closed-form solution", "Handles arbitrary non-homogeneous source terms Q(t)", "Standard baseline for linear circuit & chemical analysis"],
    limitations: ["Strictly restricted to linear 1st-order equations", "Requires symbolic integrability of P(t)"],
    idealProblems: ["RL/RC electrical circuits", "Mixing tank concentration dynamics", "Linear decay cascades"]
  },
  {
    id: "frobenius_method",
    name: "Frobenius Series Method",
    pioneerYear: "Ferdinand Georg Frobenius (1873)",
    category: "Analytical Exact",
    tagline: "Generalized power series solution around regular singular points with indicial roots",
    formulaLatex: "y(x) = x^r \\sum_{n=0}^\\infty a_n x^n, \\quad F(r) = r(r-1) + p_0 r + q_0 = 0",
    description: "Expands differential equations around regular singular points x=0. Solves the quadratic indicial equation for characteristic exponents r1, r2, constructing independent Bessel, Legendre, or hypergeometric series.",
    strengths: ["Resolves physical coordinate singularities at origin", "Exact analytic series representations", "Generates special functions of mathematical physics"],
    limitations: ["Logarithmic branch cut terms arise when r1 - r2 is an integer", "Convergence radius bounded by adjacent singularity"],
    idealProblems: ["Bessel differential equation (cylindrical acoustics)", "Legendre equation (spherical harmonics)", "Lane-Emden stellar polytropes"]
  },
  {
    id: "laplace_transform",
    name: "Laplace Transform Technique",
    pioneerYear: "Pierre-Simon Laplace (1812)",
    category: "Analytical Exact",
    tagline: "Integral transformation mapping differential operators into s-domain algebraic systems",
    formulaLatex: "\\mathcal{L}\\{y^{(n)}(t)\\} = s^n Y(s) - \\sum_{k=1}^n s^{n-k} y^{(k-1)}(0)",
    description: "Maps continuous differential operators into algebraic polynomial operations in the complex frequency domain s. Natural choice for discontinuous piecewise forcing and initial-value problems.",
    strengths: ["Directly incorporates initial conditions", "Effortlessly handles Dirac delta impulses and Heaviside steps", "Solves linear coupled systems via Cramer's rule"],
    limitations: ["Cannot directly invert non-linear algebraic convolutions", "Requires existence of inverse Laplace contour"],
    idealProblems: ["Impulse-driven mechanical oscillators", "RLC transient circuit response", "Control systems transfer functions"]
  },
  {
    id: "greens_functions",
    name: "Green's Functions Method",
    pioneerYear: "George Green (1828)",
    category: "Analytical Exact",
    tagline: "Integral kernel representation expressing response to arbitrary distributed source distributions",
    formulaLatex: "L[G(x, \\xi)] = \\delta(x - \\xi) \\implies y(x) = \\int_a^b G(x, \\xi) f(\\xi) \\, d\\xi",
    description: "Constructs the fundamental impulse response kernel G(x, xi) of a linear differential operator satisfying boundary conditions, expressing particular solutions via one-dimensional integral quadratures.",
    strengths: ["Decouples operator boundary geometry from arbitrary forcing functions", "Fundamental in electrostatics, quantum mechanics, and elasticity"],
    limitations: ["Requires finding homogeneous fundamental solutions and Wronskian", "Restricted to linear boundary value problems"],
    idealProblems: ["Electrostatic Poisson equation", "Deflection of loaded elastic beams", "Sturm-Liouville boundary value problems"]
  },
  {
    id: "fourier_analysis",
    name: "Fourier Series & Transform",
    pioneerYear: "Joseph Fourier (1822)",
    category: "Analytical Exact",
    tagline: "Orthogonal trigonometric eigenfunction expansion for boundary-value and wave systems",
    formulaLatex: "f(x) = \\frac{a_0}{2} + \\sum_{n=1}^\\infty \\left[a_n \\cos\\left(\\frac{n\\pi x}{L}\\right) + b_n \\sin\\left(\\frac{n\\pi x}{L}\\right)\\right]",
    description: "Projects functions onto complete orthogonal bases of sines and cosines. Converts linear partial differential equations on bounded domains into infinite decoupled harmonic algebraic systems.",
    strengths: ["Exact frequency domain insight", "Orthogonality simplifies coefficient calculations", "Solves heat conduction and standing wave acoustics"],
    limitations: ["Gibbs phenomenon overshoot near jump discontinuities", "Restricted to linear systems"],
    idealProblems: ["Transient heat diffusion in cylinders", "Vibrating strings and membranes", "Spectral filtering in electrical signals"]
  },
  {
    id: "variation_parameters",
    name: "Variation of Parameters",
    pioneerYear: "Joseph-Louis Lagrange (1774)",
    category: "Analytical Exact",
    tagline: "Universal non-homogeneous particular solution via Wronskian determinants",
    formulaLatex: "y_p(t) = -y_1(t)\\int \\frac{y_2(t) g(t)}{W(t)}dt + y_2(t)\\int \\frac{y_1(t) g(t)}{W(t)}dt",
    description: "General method for finding particular solutions to linear differential equations where undetermined coefficients fails due to non-polynomial forcing functions (e.g., sec(t), tan(t)).",
    strengths: ["Applicable to arbitrary non-polynomial forcing functions", "Rigorous closed form via Wronskian W(t)"],
    limitations: ["Requires prior knowledge of homogeneous fundamental set {y1, y2}", "Integral quadratures can be non-elementary"],
    idealProblems: ["Driven harmonic oscillators with secular forcing", "Airy and Bessel differential equations"]
  },

  // -------------------------------------------------------------------------
  // 2. Semi-Analytical Methods (DTM & OHAM Highlighted)
  // -------------------------------------------------------------------------
  {
    id: "dtm",
    name: "Differential Transform Method (DTM)",
    pioneerYear: "J.K. Zhou (1986); Chen & Ho (1999)",
    category: "Semi-Analytical",
    tagline: "Maps differential operators into algebraic recurrence relations in discrete k-space without quadratures",
    formulaLatex: "U(k) = \\frac{1}{k!}\\left[\\frac{d^k u(t)}{dt^k}\\right]_{t=t_0} \\iff u(t) = \\sum_{k=0}^N U(k)(t-t_0)^k",
    description: "An elegant semi-analytical iterative technique based on Taylor series expansions that transforms differential equations into discrete algebraic recurrence formulas. Completely avoids symbolic integral quadratures, perturbation parameters, or discretization grids.",
    strengths: [
      "Purely algebraic recursive evaluation—zero numerical or symbolic integration required",
      "Remarkable computational velocity per expansion order (milliseconds)",
      "Exact discrete convolution rules transform nonlinearities u^2, u^3, u*v directly",
      "Seamlessly accelerated via Padé rational approximants to exceed convergence radius"
    ],
    limitations: [
      "Polynomial convergence horizon bounded by complex-plane singular poles unless Padé accelerated",
      "Requires equations with smooth analytic or polynomial nonlinear operators"
    ],
    idealProblems: [
      "Nonlinear Riccati IVP (u' + u^2 = 1)",
      "Duffing nonlinear oscillator with cubic stiffness",
      "Astrophysical Lane-Emden polytropic spheres",
      "Blasius and Falkner-Skan boundary layer fluid flows"
    ],
    convergenceParameters: [
      {
        name: "Truncation Order",
        symbol: "N",
        role: "Governs polynomial degree and spectral bandwidth of the reconstructed inverse transform.",
        guideline: "Standard range N = 3 to 10. Higher orders improve near-origin accuracy; pair with Padé [N/2, N/2] for large t."
      },
      {
        name: "Expansion Center",
        symbol: "t_0",
        role: "Point of expansion where initial conditions or boundary conditions are known.",
        guideline: "Typically t_0 = 0. For multi-interval domains, DTM can be chained as a piecewise multi-step DTM (MS-DTM)."
      },
      {
        name: "Convergence Radius",
        symbol: "H",
        role: "Maximum time horizon |t - t_0| < H before truncated Taylor series diverges.",
        guideline: "Determined by distance to nearest complex pole (e.g. H = pi/2 for Riccati u = tanh(t))."
      },
      {
        name: "Padé Post-Acceleration",
        symbol: "[M/N]",
        role: "Converts Taylor polynomial into rational approximant P_M(t)/Q_N(t) to suppress divergence.",
        guideline: "Recommended diagonal Padé [3/3] or [4/4] for infinite-domain asymptotes."
      }
    ],
    algorithmicSteps: [
      {
        step: "Step 1",
        name: "Transform Continuous Differential Equation",
        description: "Apply standard DTM transformation identities to continuous equation.",
        latex: "D\\left\\{\\frac{d^m u}{dt^m}\\right\\} = \\frac{(k+m)!}{k!} U(k+m), \\quad D\\{u^2\\} = \\sum_{r=0}^k U(r) U(k-r)"
      },
      {
        step: "Step 2",
        name: "Incorporate Initial / Boundary Conditions",
        description: "Map initial state values directly into initial transform coefficients.",
        latex: "u(0) = u_0 \\implies U(0) = u_0, \\quad u'(0) = v_0 \\implies U(1) = v_0"
      },
      {
        step: "Step 3",
        name: "Execute Discrete Algebraic Recurrence",
        description: "Iterate recurrence formula from k = 0 to N-1 to calculate U(1), U(2), ..., U(N) purely algebraically.",
        latex: "U(k+1) = \\frac{1}{k+1} \\left[ 2 U(k) - \\sum_{r=0}^k U(r)U(k-r) + \\delta(k) \\right]"
      },
      {
        step: "Step 4",
        name: "Inverse Differential Transform Reconstruction",
        description: "Reconstruct continuous time series as a polynomial sum.",
        latex: "u(t) = \\sum_{k=0}^N U(k) (t - t_0)^k"
      },
      {
        step: "Step 5",
        name: "Padé Post-Processing & Residual Verification",
        description: "Evaluate residual R(t) = L(u) + N(u) - g(t) and apply rational Padé quotient [M/N](t) if large t is required."
      }
    ]
  },
  {
    id: "oham",
    name: "Optimal Homotopy Asymptotic Method (OHAM)",
    pioneerYear: "V. Marinca & N. Herisanu (2008)",
    category: "Semi-Analytical",
    tagline: "Rigorous convergence-control via least-squares functional residual minimization of auxiliary constants",
    formulaLatex: "(1-p)[L(\\phi(t;p)) + g(t)] = H(t,p)[L(\\phi(t;p)) + g(t) + N(\\phi(t;p))]",
    description: "An advanced semi-analytical methodology developed by Marinca and Herisanu. OHAM overcomes the trial-and-error convergence search of HAM by introducing an auxiliary polynomial function H(t, p) = sum p^i C_i whose constants C_1, C_2, ... are determined via least-squares residual minimization.",
    strengths: [
      "Rigorous mathematical convergence control—no manual eyeballing of h-bar curves",
      "Explicitly minimizes square residual integral J(C1, C2, ...) over physical domain [0, T]",
      "Exceptional accuracy even at very low deformation orders (m = 1 or 2)",
      "Unconditionally stable for strongly nonlinear conservative and dissipative oscillators"
    ],
    limitations: [
      "Requires solving an auxiliary least-squares nonlinear optimization problem for constants C_i",
      "Expression growth in higher-order nonlinear operators N_m"
    ],
    idealProblems: [
      "Nonlinear quadratic Riccati IVP",
      "Saturating logistic growth with inflection",
      "Duffing oscillator under periodic harmonic forcing",
      "Non-Newtonian fluid boundary layers and heat transfer"
    ],
    convergenceParameters: [
      {
        name: "Auxiliary Constants",
        symbol: "C_1, C_2, \\dots, C_m",
        role: "Optimal convergence-control parameters embedded in the homotopy deformation.",
        guideline: "Determined uniquely by stationary condition dJ/dC_i = 0 of the square residual functional."
      },
      {
        name: "Auxiliary Function",
        symbol: "H(t, p)",
        role: "Polynomial or exponential deformation controller H(t, p) = p C_1 + p^2 C_2 + ...",
        guideline: "For finite domains, polynomial H(p) = sum p^i C_i suffices; for unbounded domains, use e^{-t} weighting."
      },
      {
        name: "Residual Error Functional",
        symbol: "J(C_1, \\dots, C_m)",
        role: "Objective function: L2 integral of differential equation residual over [0, T].",
        guideline: "J = int_0^T R^2(t; C_1, ...) dt -> min. Solved via Nelder-Mead simplex or BFGS."
      },
      {
        name: "Collocation Variant",
        symbol: "t_i",
        role: "Alternative to integral minimization: enforces zero residual at discrete collocation points.",
        guideline: "Choose m Chebyshev-distributed nodes t_i in [0, T] and solve algebraic system R(t_i; C_j) = 0."
      }
    ],
    algorithmicSteps: [
      {
        step: "Step 1",
        name: "Decomposition into Linear and Nonlinear Operators",
        description: "Partition the differential equation into linear operator L, source term g(t), and nonlinear operator N.",
        latex: "L(u(t)) + g(t) + N(u(t)) = 0, \\quad B(u, u') = 0"
      },
      {
        step: "Step 2",
        name: "Construct Continuous Homotopy Deformation",
        description: "Introduce embedding parameter p in [0, 1] and auxiliary convergence function H(t, p).",
        latex: "(1-p)[L(\\phi(t; p)) + g(t)] = H(t, p)[L(\\phi(t; p)) + g(t) + N(\\phi(t; p))], \\quad H(t, p) = \\sum_{i=1}^m p^i C_i"
      },
      {
        step: "Step 3",
        name: "Perturbation Series Expansion in Powers of p",
        description: "Expand phi(t; p) = v_0(t) + sum_{i=1}^m v_i(t; C_1, ..., C_i) p^i and equate like powers of p.",
        latex: "p^0: L(v_0) + g(t) = 0, \\quad p^1: L(v_1) = C_1 N_0(v_0), \\quad p^2: L(v_2) - (1+C_1)L(v_1) = C_2 N_0(v_0) + C_1 N_1"
      },
      {
        step: "Step 4",
        name: "Formulate m-th Order Approximate Solution",
        description: "Set p = 1 to recover physical solution parameterized by constants C_i.",
        latex: "\\tilde{u}(t; C_1, \\dots, C_m) = v_0(t) + \\sum_{i=1}^m v_i(t; C_1, \\dots, C_i)"
      },
      {
        step: "Step 5",
        name: "Functional Residual Minimization (Stationary Point)",
        description: "Compute residual R(t; C) and minimize square residual integral J(C) using Nelder-Mead or BFGS.",
        latex: "J(C_1, \\dots, C_m) = \\int_{0}^T R^2(t; C_1, \\dots, C_m) \\, dt \\implies \\frac{\\partial J}{\\partial C_i} = 0 \\quad (i=1,\\dots,m)"
      }
    ]
  },
  {
    id: "ham",
    name: "Homotopy Analysis Method (HAM)",
    pioneerYear: "Shijun Liao (1992, 2003, 2012)",
    category: "Semi-Analytical",
    tagline: "Universal convergence control via auxiliary linear operator L and parameter h-bar",
    formulaLatex: "(1-q)\\mathcal{L}[\\phi(t;q) - u_0(t)] = q\\,\\hbar\\,H(t)\\,\\mathcal{N}[\\phi(t;q)]",
    description: "Pioneered by Shijun Liao, HAM generalizes traditional perturbation methods by introducing the non-zero convergence-control parameter h-bar and auxiliary linear operator L, giving users the explicit power to adjust and ensure the convergence region of the series solution.",
    strengths: [
      "Rigorous convergence control via h-bar curve plateaus",
      "Works on strongly nonlinear equations where all other series diverge",
      "Supports non-polynomial auxiliary base functions"
    ],
    limitations: [
      "Requires h-bar optimization step",
      "Higher order terms require symbolic algebra"
    ],
    idealProblems: [
      "Stiff chemical kinetics with boundary layers",
      "Boundary layer flows over stretching sheets",
      "Nonlinear fractional diffusion"
    ],
    convergenceParameters: [
      {
        name: "Convergence-Control Parameter",
        symbol: "\\hbar",
        role: "Governs convergence region and rate of the homotopy deformation series.",
        guideline: "Identify flat horizontal plateau in h-bar curve where d(u)/d(hbar) ~ 0."
      },
      {
        name: "Auxiliary Linear Operator",
        symbol: "\\mathcal{L}",
        role: "Determines fundamental base functions (polynomial, exponential, trigonometric).",
        guideline: "Must possess simple inverse and satisfy initial boundary conditions."
      }
    ]
  },
  {
    id: "hpm",
    name: "Homotopy Perturbation Method (HPM)",
    pioneerYear: "Ji-Huan He (1999)",
    category: "Semi-Analytical",
    tagline: "Blends topology homotopy deformation with perturbation series expansion evaluated at p = 1",
    formulaLatex: "\\mathcal{H}(v, p) = (1-p)[L(v) - L(u_0)] + p[L(v) + N(v) - g(t)] = 0",
    description: "Introduces an artificial continuous embedding parameter p in [0, 1] deforming an easy initial linear problem into the targeted nonlinear problem. Freedom to choose initial approximation u0.",
    strengths: ["Highly intuitive homotopy interpretation", "Extremely rapid convergence for initial orders", "No need for small physical parameter"],
    limitations: ["Requires careful selection of linear operator L to avoid divergence", "Higher orders involve large polynomial expressions"],
    idealProblems: ["Duffing nonlinear oscillator", "Van der Pol limit cycles", "Thermal radiation conduction equations"]
  },
  {
    id: "adm",
    name: "Adomian Decomposition Method (ADM)",
    pioneerYear: "George Adomian (1984, 1994)",
    category: "Semi-Analytical",
    tagline: "Decomposes nonlinear operators into polynomials A_n without discretization",
    formulaLatex: "u(t) = \\sum_{n=0}^\\infty u_n(t), \\quad N(u) = \\sum_{n=0}^\\infty A_n(u_0, \\dots, u_n)",
    description: "Systematic decomposition separating differential equations into inverse linear integral operators and generalized Adomian polynomials A_n. Avoids perturbation parameters and spatial discretization.",
    strengths: ["No small or large perturbation parameter needed", "Pure symbolic recursive integration", "Handles strong algebraic and transcendental nonlinearities"],
    limitations: ["Convergence radius limited by complex-plane singularity poles", "Computational cost increases with order"],
    idealProblems: ["Riccati equations", "Nonlinear Lane-Emden polytropes", "Coupled predator-prey systems"]
  },
  {
    id: "vim",
    name: "Variational Iteration Method (VIM)",
    pioneerYear: "Ji-Huan He (1999, 2007)",
    category: "Semi-Analytical",
    tagline: "Constructs correction functionals using optimal variational Lagrange multipliers",
    formulaLatex: "u_{n+1}(t) = u_n(t) + \\int_0^t \\lambda(\\tau)\\left[L u_n(\\tau) + \\widetilde{N u_n(\\tau)} - g(\\tau)\\right]d\\tau",
    description: "Formulates a generalized variational correction functional where the optimal Lagrange multiplier lambda(tau) is determined via calculus of variations and stationary conditions.",
    strengths: ["Optimal Lagrange multiplier accelerates convergence", "Physical variational grounding", "Few iterations required for high accuracy"],
    limitations: ["Determining lambda for variable coefficient systems can be non-trivial", "Evaluation of restricted variational variations"],
    idealProblems: ["Thermoelasticity problems", "Nonlinear wave equations", "Helmut-Gelfand boundary value problems"]
  },

  // -------------------------------------------------------------------------
  // 3. Perturbation & Asymptotic Methods
  // -------------------------------------------------------------------------
  {
    id: "mms",
    name: "Method of Multiple Scales (MMS)",
    pioneerYear: "J. Cole & J. Kevorkian (1960s)",
    category: "Perturbation & Asymptotic",
    tagline: "Separates fast and slow time scales to eliminate resonant secular growth",
    formulaLatex: "T_0 = t, \\; T_1 = \\epsilon t, \\dots \\implies \\frac{d}{dt} = \\frac{\\partial}{\\partial T_0} + \\epsilon \\frac{\\partial}{\\partial T_1} + \\dots",
    description: "Powerful singular perturbation method designed for oscillatory dynamical systems where regular perturbation produces unphysical secular terms proportional to t*cos(omega*t).",
    strengths: ["Eliminates secular terms systematically", "Reveals slow modulation of amplitude and phase", "Captures limit cycle radii and bifurcation thresholds"],
    limitations: ["Requires small parameter epsilon << 1", "Demands algebraic skill in solvability conditions"],
    idealProblems: ["Van der Pol self-excited oscillator", "Duffing resonance and jump phenomena", "Parametrically excited pendulums"]
  },
  {
    id: "wkb",
    name: "WKB / Liouville-Green Approximation",
    pioneerYear: "Wentzel, Kramers, Brillouin (1926)",
    category: "Perturbation & Asymptotic",
    tagline: "Asymptotic solution for differential equations with rapidly varying coefficients",
    formulaLatex: "\\epsilon^2 \\frac{d^2 y}{dx^2} + Q(x) y = 0 \\implies y(x) \\sim Q(x)^{-1/4} \\exp\\left(\\pm \\frac{i}{\\epsilon}\\int \\sqrt{Q} dx\\right)",
    description: "Semiclassical asymptotic technique for linear differential equations where the highest derivative is multiplied by a small parameter epsilon^2, resulting in rapid spatial oscillations or exponential decay.",
    strengths: ["Global asymptotic accuracy for high frequency waves", "Unlocks quantum tunneling and connection formulas across turning points"],
    limitations: ["Breaks down at classical turning points Q(x) = 0 without Airy connection"],
    idealProblems: ["Quantum Schrödinger wave equation", "Acoustic wave propagation in stratified media", "High-frequency boundary layers"]
  },
  {
    id: "matched_asymptotics",
    name: "Matched Asymptotic Expansions",
    pioneerYear: "Ludwig Prandtl (1904); Kaplun & Lagerstrom",
    category: "Perturbation & Asymptotic",
    tagline: "Singular perturbation method matching inner boundary layers with outer inviscid flows",
    formulaLatex: "\\lim_{x \\to 0} y_{\\text{outer}}(x) = \\lim_{X \\to \\infty} y_{\\text{inner}}(X), \\quad X = \\frac{x}{\\epsilon^\\alpha}",
    description: "Solves singularly perturbed differential equations where small parameters multiply the highest derivative, generating narrow boundary layers where solution gradients blow up. Matches inner and outer expansions in an intermediate overlap zone.",
    strengths: ["Resolves extreme multi-scale stiffness", "Provides uniform composite analytical expansions"],
    limitations: ["Determining boundary layer scaling exponent alpha requires significant physical intuition"],
    idealProblems: ["Fluid dynamic boundary layers over airfoils", "Slow-fast relaxation chemical kinetics", "Membrane boundary stress concentrations"]
  },

  // -------------------------------------------------------------------------
  // 4. Series Acceleration
  // -------------------------------------------------------------------------
  {
    id: "pade",
    name: "Padé Rational Approximants [M/N]",
    pioneerYear: "Henri Padé (1892)",
    category: "Series Acceleration",
    tagline: "Rational transformation P_M(t)/Q_N(t) overcoming series divergence and complex poles",
    formulaLatex: "[M/N](t) = \\frac{\\sum_{i=0}^M p_i t^i}{1 + \\sum_{j=1}^N q_j t^j} = \\sum_{k=0}^{M+N} c_k t^k + \\mathcal{O}(t^{M+N+1})",
    description: "Transforms truncated power series into rational functions, placing poles in the complex plane to match non-physical singularities and drastically extending the convergence domain.",
    strengths: ["Vastly expands radius of convergence beyond Taylor horizon", "Correctly captures asymptotic horizontal limits as t -> infinity", "Eliminates secular runaway"],
    limitations: ["Spurious defects (Froissart doublets) if numerator and denominator share near-zeros"],
    idealProblems: ["Post-processing ADM/HPM/HAM/DTM power series", "Transcritical bifurcation asymptotes", "Boundary layer shear stress"]
  },

  // -------------------------------------------------------------------------
  // 5. High-Order Numerical Solvers
  // -------------------------------------------------------------------------
  {
    id: "dop853",
    name: "DOP853 (8th-Order Adaptive Runge-Kutta)",
    pioneerYear: "Dormand & Prince (1980)",
    category: "High-Order Numerical",
    tagline: "Dormand-Prince 8(5,3) explicit integrator for ultra-precise non-stiff scientific problems",
    formulaLatex: "u_{n+1} = u_n + h \\sum_{i=1}^{12} b_i k_i, \\quad \\text{Local Error} = \\mathcal{O}(h^9)",
    description: "State-of-the-art 8th-order explicit Runge-Kutta integrator with embedded 5th and 3rd order error estimators and continuous dense output interpolation. Gold standard for smooth celestial, molecular, and trajectory problems.",
    strengths: ["Ultra-tight error tolerances (1e-12 to 1e-15)", "Adaptive step-size control minimizes function evaluations", "Ultra-smooth dense output interpolation"],
    limitations: ["Undergoes severe step-size collapse on stiff differential equations"],
    idealProblems: ["N-body celestial mechanics", "Non-stiff chaotic attractors (Lorenz, Rössler)", "Molecular dynamics trajectories"]
  },
  {
    id: "radau_iia",
    name: "Radau IIA Implicit Runge-Kutta",
    pioneerYear: "E. Hairer & G. Wanner (1996)",
    category: "High-Order Numerical",
    tagline: "Fully A-stable and L-stable 5th-order implicit integrator for stiff systems & DAEs",
    formulaLatex: "u_{n+1} = u_n + h \\sum_{i=1}^s b_i f(t_n + c_i h, Z_i), \\quad Z_i = u_n + h\\sum_{j=1}^s a_{ij} f(t_n + c_j h, Z_j)",
    description: "Implicit Runge-Kutta method based on Radau quadrature points. Provides both A-stability and L-stability, ensuring extreme damping of stiff components without artificial numerical oscillations.",
    strengths: ["Unconditionally stable for stiff equations", "Solves Differential-Algebraic Equations (DAEs) of index 1, 2, and 3", "Handles rapid chemical kinetics with zero step collapse"],
    limitations: ["Requires Newton iterations with Jacobian matrix inversions at every step"],
    idealProblems: ["Robertson stiff chemical cascade", "Electrical power grid transients", "Constrained multibody mechanics"]
  },
  {
    id: "lsoda",
    name: "LSODA (Automatic Stiff / Non-Stiff Switching)",
    pioneerYear: "Petzold & Hindmarsh (1983)",
    category: "High-Order Numerical",
    tagline: "Dynamically switches between Adams-Moulton (non-stiff) and BDF (stiff) methods",
    formulaLatex: "\\text{If Stiff } \\implies \\sum_{i=0}^k \\alpha_i y_{n+1-i} = h \\beta_0 f(t_{n+1}, y_{n+1}) \\quad (\\text{BDF})",
    description: "Livermore Solver for Ordinary Differential Equations with Automatic method switching. Dynamically monitors stiffness ratio during integration and seamlessly alternates between explicit Adams predictor-corrector and implicit Gear BDF.",
    strengths: ["Optimal balance of speed and stability", "Requires zero manual guessing about problem stiffness", "Robust for systems that enter transient stiff regimes"],
    limitations: ["Step size overhead during method switching"],
    idealProblems: ["Combustion ignition delay fronts", "Atmospheric photochemistry", "Biological bursting neurons"]
  },
  {
    id: "symplectic_verlet",
    name: "Symplectic Störmer-Verlet Integrator",
    pioneerYear: "Carl Störmer (1907); Loup Verlet (1967)",
    category: "High-Order Numerical",
    tagline: "Geometric phase-space volume and Hamiltonian energy preserving integrator",
    formulaLatex: "p_{n+1/2} = p_n - \\frac{h}{2}\\nabla V(q_n), \\quad q_{n+1} = q_n + h p_{n+1/2}, \\quad p_{n+1} = p_{n+1/2} - \\frac{h}{2}\\nabla V(q_{n+1})",
    description: "Geometric numerical integrator for conservative Hamiltonian systems. Exactly preserves symplectic 2-forms, preventing artificial energy drift over astronomical simulation horizons.",
    strengths: ["Exact preservation of Poincaré phase-space invariants", "Bounded energy oscillations over millions of steps", "Time-reversible"],
    limitations: ["Restricted to Hamiltonian and separable conservative systems"],
    idealProblems: ["Planetary orbital longevity", "Molecular dynamics thermostats", "Conservative wave equations"]
  },
  {
    id: "spectral_collocation",
    name: "Chebyshev Spectral Collocation",
    pioneerYear: "Cornelius Lanczos (1938); Orszag (1971)",
    category: "High-Order Numerical",
    tagline: "Exponential (spectral) convergence for smooth differential boundary-value problems",
    formulaLatex: "x_j = \\cos\\left(\\frac{j\\pi}{N}\\right), \\quad u'(x_j) = \\sum_{k=0}^N D_{jk} u(x_k)",
    description: "Discretizes differential operators on Gauss-Lobatto-Chebyshev nodes using differentiation matrices D. Delivers spectral accuracy (error drops faster than any algebraic power N^-k) for smooth boundary-value problems.",
    strengths: ["Exponential convergence rate", "Requires far fewer mesh nodes than finite differences", "Exceptional for fluid stability and eigenvalue problems"],
    limitations: ["Dense matrix operators require O(N^3) solves", "Sensitive to domain geometry"],
    idealProblems: ["Hydrodynamic Orr-Sommerfeld stability", "Thermal convection Rayleigh-Bénard cells", "Quantum harmonic oscillators"]
  }
];

interface MethodCatalogProps {
  onSelectMethod?: (methodId: string) => void;
}

export const MethodCatalog: React.FC<MethodCatalogProps> = ({ onSelectMethod }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeMethodId, setActiveMethodId] = useState<string>("dtm");

  // Interactive Live Tester State
  const [testProblem, setTestProblem] = useState<string>("riccati_ivp");
  const [testOrder, setTestOrder] = useState<number>(4);
  const [testRunning, setTestRunning] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [testError, setTestError] = useState<string | null>(null);

  const categories = [
    "ALL",
    "Analytical Exact",
    "Semi-Analytical",
    "Perturbation & Asymptotic",
    "Series Acceleration",
    "High-Order Numerical"
  ];

  const filteredMethods = METHODS_CATALOG.filter(m => {
    const matchesCat = selectedCategory === "ALL" || m.category === selectedCategory;
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.tagline.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const activeMethod =
    METHODS_CATALOG.find(m => m.id === activeMethodId) || METHODS_CATALOG[0];

  // Execute interactive live runner for active method (DTM, OHAM, HAM, etc.)
  const handleRunLiveMethod = async () => {
    setTestRunning(true);
    setTestError(null);
    setTestResult(null);

    try {
      let endpoint = "/api/run-method";
      let payload: any = {
        problemId: testProblem,
        order: testOrder
      };

      if (activeMethod.id === "dtm") {
        endpoint = "/api/run-dtm";
      } else if (activeMethod.id === "oham") {
        endpoint = "/api/run-oham";
      } else {
        payload.method = activeMethod.id.toUpperCase();
      }

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error(`Execution error: ${res.statusText}`);
      }

      const data = await res.json();
      setTestResult(data);
    } catch (err: any) {
      setTestError(err.message || "Failed to execute method computation.");
    } finally {
      setTestRunning(false);
    }
  };

  return (
    <div className="space-y-6 font-serif">
      {/* 1937 Monograph Header Plate */}
      <div className="vintage-plate p-6 rounded-sm relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b-2 border-[#8e7a60] pb-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5 text-xs text-[#7a6a54]">
              <span className="font-cinzel font-bold text-[#8b281a] tracking-wider uppercase">
                Annals of Mathematical Computation
              </span>
              <span>·</span>
              <span className="italic font-garamond">Tome XXXVII · Anno 1937</span>
              <span>·</span>
              <span className="font-cinzel text-[#2b241b]">17 Universal Solvers</span>
            </div>
            <h2 className="text-2xl font-cinzel font-bold text-[#1a1713] tracking-wide">
              Universal Mathematical Method Taxonomy & Solver Catalog
            </h2>
            <p className="text-sm text-[#4d4134] mt-1 max-w-3xl leading-relaxed font-garamond">
              A comprehensive treatise on analytical exact solutions, modern semi-analytical series deformations 
              (DTM, OHAM, HAM, HPM, ADM, VIM), asymptotic perturbation expansions, and high-order numerical integrators.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="border-2 border-[#8b281a] px-3 py-1.5 text-center bg-[#fdfcfa]">
              <div className="text-[10px] font-cinzel font-bold uppercase tracking-widest text-[#8b281a]">
                Standard Formulation
              </div>
              <div className="text-xs font-garamond text-[#3a3024] font-semibold">
                L(u) + N(u) = g(t)
              </div>
            </div>
          </div>
        </div>

        {/* Filter Bar styled as classic letterpress segmented tabs */}
        <div className="mt-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-[#ede4d1] border border-[#d2c4ae] rounded-xs no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 text-xs font-garamond transition-all rounded-xs whitespace-nowrap ${
                  selectedCategory === cat
                    ? "bg-[#2b2217] text-[#faf6ee] font-semibold shadow-xs"
                    : "text-[#5c4f3d] hover:text-[#1a1713] hover:bg-[#dfd4c0]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#786a56]" />
            <input
              type="text"
              placeholder="Search solvers or formulas..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-[#fdfcfa] border border-[#c8bba3] rounded-xs pl-8 pr-3 py-1.5 text-xs text-[#1a1713] placeholder-[#8a7b68] focus:outline-none focus:ring-1 focus:ring-[#8b281a] font-garamond"
            />
          </div>
        </div>
      </div>

      {/* Main Grid: Left method list, Right deep-dive inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Method List */}
        <div className="lg:col-span-5 space-y-2.5 max-h-[850px] overflow-y-auto pr-1">
          {filteredMethods.map(m => {
            const isActive = m.id === activeMethodId;
            return (
              <div
                key={m.id}
                onClick={() => setActiveMethodId(m.id)}
                className={`p-3.5 rounded-xs border cursor-pointer transition-all ${
                  isActive
                    ? "bg-[#fdfcfa] border-l-4 border-l-[#8b281a] border-t-[#c8bba3] border-r-[#c8bba3] border-b-[#c8bba3] shadow-sm"
                    : "bg-[#f6f1e5] hover:bg-[#ede5d3] border-[#ded3be] text-[#3a3023]"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-cinzel tracking-wider text-[#7a6850]">
                      {m.pioneerYear}
                    </span>
                    <span className="text-[10px] text-[#8e7a60]">·</span>
                    <span className="text-[10px] font-cinzel text-[#8b281a] font-bold">
                      {m.category}
                    </span>
                  </div>
                  {isActive && (
                    <span className="text-[10px] font-cinzel uppercase text-[#8b281a] font-bold flex items-center gap-1">
                      <span>Selected</span>
                      <ChevronRight className="w-3 h-3" />
                    </span>
                  )}
                </div>

                <h4 className="font-cinzel font-bold text-sm text-[#1a1713] mt-1">
                  {m.name}
                </h4>

                <p className="text-xs text-[#524434] mt-0.5 line-clamp-2 font-garamond leading-relaxed">
                  {m.tagline}
                </p>

                <div className="mt-2 pt-2 border-t border-[#e2d6c2] overflow-x-auto text-xs bg-[#f4ece0] p-1.5 rounded-xs">
                  <MathView latex={m.formulaLatex} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Method Detailed Deep-Dive & Live Workbench */}
        <div className="lg:col-span-7 space-y-4">
          <div className="vintage-plate p-5 rounded-xs space-y-4">
            {/* Header */}
            <div className="border-b-2 border-[#8e7a60] pb-3">
              <div className="flex items-center justify-between text-xs text-[#7a6850] mb-1">
                <span className="font-cinzel uppercase tracking-widest font-semibold text-[#8b281a]">
                  Method Dossier · {activeMethod.category}
                </span>
                <span className="italic font-garamond">{activeMethod.pioneerYear}</span>
              </div>
              <h3 className="font-cinzel text-xl font-bold text-[#1a1713]">
                {activeMethod.name}
              </h3>
              <p className="text-xs text-[#524434] italic font-garamond mt-0.5">
                {activeMethod.tagline}
              </p>
            </div>

            {/* Mathematical Formula Plate */}
            <div className="bg-[#f5ede0] border border-[#d0c2ab] p-3 rounded-xs text-center shadow-inner">
              <div className="text-[10px] uppercase tracking-wider font-cinzel text-[#7a6850] mb-1">
                Governing Formulation / Recurrence Operator
              </div>
              <div className="text-sm overflow-x-auto py-1">
                <MathView latex={activeMethod.formulaLatex} />
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <h5 className="font-cinzel text-xs font-bold text-[#2a2217] uppercase tracking-wider">
                Theoretical Description & Mechanics
              </h5>
              <p className="text-xs text-[#3d3326] font-garamond leading-relaxed">
                {activeMethod.description}
              </p>
            </div>

            {/* Specific Convergence Parameters (DTM, OHAM, HAM) */}
            {activeMethod.convergenceParameters && (
              <div className="space-y-2 pt-2 border-t border-[#e2d6c2]">
                <h5 className="font-cinzel text-xs font-bold text-[#8b281a] uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Specific Convergence Parameters & Control Guidelines</span>
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeMethod.convergenceParameters.map((param, pIdx) => (
                    <div
                      key={pIdx}
                      className="bg-[#f7f2e7] border border-[#ded1be] p-2.5 rounded-xs space-y-1"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-cinzel font-bold text-[#2b2217]">
                          {param.name}
                        </span>
                        <span className="px-1.5 py-0.2 bg-[#eae0cd] border border-[#c8bca7] text-[#8b281a] font-mono text-[10px] rounded-xs font-bold">
                          ${param.symbol}$
                        </span>
                      </div>
                      <p className="text-[11px] text-[#4a3f31] font-garamond leading-snug">
                        {param.role}
                      </p>
                      <div className="text-[10px] text-[#6b5d49] italic font-garamond border-t border-[#e6dcce] pt-1 mt-1">
                        Rule: {param.guideline}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Step-by-Step Algorithmic Steps */}
            {activeMethod.algorithmicSteps && (
              <div className="space-y-2 pt-2 border-t border-[#e2d6c2]">
                <h5 className="font-cinzel text-xs font-bold text-[#2b2217] uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#8b281a]" />
                  <span>Algorithmic Execution Protocol</span>
                </h5>
                <div className="space-y-2">
                  {activeMethod.algorithmicSteps.map((step, sIdx) => (
                    <div
                      key={sIdx}
                      className="bg-[#faf6ee] border-l-2 border-l-[#8b281a] border-t border-r border-b border-[#dfd4c0] p-2.5 rounded-xs"
                    >
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-cinzel font-bold text-[#8b281a]">
                          {step.step}:
                        </span>
                        <span className="font-cinzel font-semibold text-[#1a1713]">
                          {step.name}
                        </span>
                      </div>
                      <p className="text-xs text-[#4a3f31] font-garamond mt-1 leading-relaxed">
                        {step.description}
                      </p>
                      {step.latex && (
                        <div className="mt-1.5 p-1 bg-[#f3ede1] rounded-xs text-xs overflow-x-auto">
                          <MathView latex={step.latex} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Strengths & Limitations */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#e2d6c2]">
              <div className="bg-[#f6f9f4] border border-[#cfdfcb] p-3 rounded-xs space-y-1">
                <div className="text-xs font-cinzel font-bold text-[#2d5038] uppercase tracking-wider flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Analytical Strengths</span>
                </div>
                <ul className="text-xs text-[#37523f] font-garamond space-y-1 leading-snug list-disc list-inside">
                  {activeMethod.strengths.map((s, idx) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#fcf6f5] border border-[#e8d2ce] p-3 rounded-xs space-y-1">
                <div className="text-xs font-cinzel font-bold text-[#8b281a] uppercase tracking-wider flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Mathematical Limitations</span>
                </div>
                <ul className="text-xs text-[#6e372e] font-garamond space-y-1 leading-snug list-disc list-inside">
                  {activeMethod.limitations.map((l, idx) => (
                    <li key={idx}>{l}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Ideal Benchmark Problems */}
            <div className="pt-2 border-t border-[#e2d6c2]">
              <div className="text-[10px] uppercase tracking-wider font-cinzel text-[#7a6850] mb-1">
                Exemplar Benchmark Classes:
              </div>
              <div className="flex flex-wrap gap-1.5">
                {activeMethod.idealProblems.map((p, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 bg-[#f0e8d9] border border-[#cfc0a8] text-[#3d3326] text-xs font-garamond rounded-xs"
                  >
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Interactive Live Solver Workbench */}
          <div className="vintage-plate p-5 rounded-xs space-y-3 bg-[#fdfcfa]">
            <div className="flex items-center justify-between border-b border-[#8e7a60] pb-2">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-[#8b281a]" />
                <h4 className="font-cinzel font-bold text-sm text-[#1a1713]">
                  Interactive {activeMethod.name} Testbench
                </h4>
              </div>
              <span className="text-[10px] font-cinzel text-[#7a6850] uppercase tracking-widest">
                Real-Time Python Daemon Execution
              </span>
            </div>

            <p className="text-xs text-[#524434] font-garamond">
              Execute this specific method on canonical benchmark equations to inspect order terms, convergence parameters, 
              and residual norms in real time.
            </p>

            <div className="flex flex-wrap items-center gap-3 bg-[#f6f0e2] p-3 rounded-xs border border-[#d6cab7]">
              <div>
                <label className="block text-[10px] font-cinzel font-bold uppercase text-[#5c4f3d] mb-1">
                  Benchmark Problem
                </label>
                <select
                  value={testProblem}
                  onChange={e => setTestProblem(e.target.value)}
                  className="bg-[#fdfcfa] border border-[#c5b79e] text-xs text-[#1a1713] px-2.5 py-1 rounded-xs font-garamond"
                >
                  <option value="riccati_ivp">Riccati IVP (u' + u^2 = 1, u(0)=0)</option>
                  <option value="logistic_ivp">Logistic Growth (u' = r*u*(1-u/K))</option>
                  <option value="duffing_oscillator">Duffing Oscillator (u'' + delta*u' + u + u^3)</option>
                  <option value="lane_emden">Lane-Emden Polytrope (Astrophysics)</option>
                  <option value="stiff_relaxation">Stiff Boundary Layer ODE (lambda=50)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-cinzel font-bold uppercase text-[#5c4f3d] mb-1">
                  Truncation Order N
                </label>
                <input
                  type="number"
                  min={1}
                  max={6}
                  value={testOrder}
                  onChange={e => setTestOrder(Math.max(1, Math.min(6, parseInt(e.target.value) || 2)))}
                  className="w-20 bg-[#fdfcfa] border border-[#c5b79e] text-xs text-[#1a1713] px-2.5 py-1 rounded-xs font-garamond"
                />
              </div>

              <div className="pt-4">
                <button
                  onClick={handleRunLiveMethod}
                  disabled={testRunning}
                  className="px-4 py-1.5 bg-[#2b2217] hover:bg-[#8b281a] disabled:opacity-50 text-[#faf6ee] font-cinzel text-xs font-bold tracking-wider uppercase rounded-xs transition-colors shadow-xs flex items-center gap-1.5"
                >
                  {testRunning ? (
                    <>
                      <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                      <span>Computing...</span>
                    </>
                  ) : (
                    <>
                      <span>Execute {activeMethod.id.toUpperCase()}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>

            {testError && (
              <div className="p-3 bg-[#fdf2f0] border border-[#e5c2bc] text-xs text-[#8b281a] rounded-xs font-garamond">
                {testError}
              </div>
            )}

            {testResult && (
              <div className="p-4 bg-[#fbf9f4] border border-[#d8cdb8] rounded-xs space-y-3">
                <div className="flex items-center justify-between border-b border-[#e2d6c2] pb-1.5">
                  <div className="text-xs font-cinzel font-bold text-[#8b281a]">
                    Computation Succeeded · Order {testResult.order}
                  </div>
                  <div className="text-[10px] text-[#6b5c47] font-garamond">
                    Wall time: {(testResult.wall_time_sec * 1000).toFixed(2)} ms
                  </div>
                </div>

                {/* Series Solution */}
                {testResult.series_latex && (
                  <div>
                    <div className="text-[10px] uppercase font-cinzel text-[#7a6850] mb-0.5">
                      Analytical Solution Series $u(t)$:
                    </div>
                    <div className="bg-[#f4ecdf] p-2 rounded-xs text-xs overflow-x-auto">
                      <MathView latex={testResult.series_latex} />
                    </div>
                  </div>
                )}

                {/* Recurrence Relation (DTM) or Optimal Constants (OHAM) */}
                {testResult.recurrence_relation_latex && (
                  <div>
                    <div className="text-[10px] uppercase font-cinzel text-[#7a6850] mb-0.5">
                      DTM Recurrence Formula:
                    </div>
                    <div className="bg-[#f4ecdf] p-2 rounded-xs text-xs overflow-x-auto">
                      <MathView latex={testResult.recurrence_relation_latex} />
                    </div>
                  </div>
                )}

                {testResult.c_constants && (
                  <div>
                    <div className="text-[10px] uppercase font-cinzel text-[#7a6850] mb-0.5">
                      Optimal OHAM Convergence Constants (Least Squares Residual Minimization):
                    </div>
                    <div className="flex flex-wrap gap-2 text-xs font-mono bg-[#f4ecdf] p-2 rounded-xs">
                      {testResult.c_constants.map((cVal: number, idx: number) => (
                        <span key={idx} className="bg-[#e9dfcc] px-2 py-0.5 rounded-xs text-[#8b281a] font-bold">
                          C_{idx + 1} = {cVal.toFixed(6)}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Term Expressions */}
                {testResult.term_expressions && (
                  <div>
                    <div className="text-[10px] uppercase font-cinzel text-[#7a6850] mb-0.5">
                      Calculated Order Terms:
                    </div>
                    <div className="space-y-1 text-xs font-mono max-h-32 overflow-y-auto bg-[#f4ecdf] p-2 rounded-xs text-[#3a2e21]">
                      {testResult.term_expressions.map((term: string, idx: number) => (
                        <div key={idx} className="border-b border-[#e6dbc8] pb-0.5">
                          {term}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Residual Norm */}
                {testResult.residual_norm !== undefined && (
                  <div className="flex items-center justify-between text-xs font-garamond border-t border-[#e2d6c2] pt-1.5 text-[#4a3e2e]">
                    <span>Maximum Equation Residual $||R(t)||_\\infty$:</span>
                    <span className="font-mono font-bold text-[#8b281a]">
                      {testResult.residual_norm.toExponential(4)}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
