/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  Layers,
  Plus,
  Trash2,
  Download,
  Share2,
  Copy,
  Check,
  Play,
  ArrowRight,
  Maximize2,
  RotateCcw,
  Sparkles,
  Edit3,
  Sliders,
  Move,
  Code2,
  FileCode,
  FileText,
  Activity,
  Zap,
  Info
} from "lucide-react";
import { MathView } from "./MathView";

export interface CompartmentNode {
  id: string;
  name: string;
  subscript?: string;
  x: number;
  y: number;
  initialValue: number;
  color: string;
  description?: string;
}

export interface FlowLink {
  id: string;
  fromNodeId: string | null; // null if inflow from outside source
  toNodeId: string | null;   // null if outflow to outside sink
  rateFormula: string;
  rateLatex: string;
  parameterNames: string[];
  description?: string;
}

export interface PresetModel {
  id: string;
  name: string;
  category: string;
  description: string;
  nodes: CompartmentNode[];
  links: FlowLink[];
}

const PRESET_MODELS: PresetModel[] = [
  {
    id: "sir",
    name: "SIR Compartmental Epidemic",
    category: "Epidemiology",
    description: "Kermack-McKendrick epidemic flow with transmission infection and recovery.",
    nodes: [
      { id: "S", name: "S", subscript: "t", x: 140, y: 160, initialValue: 0.99, color: "#3b82f6", description: "Susceptible population" },
      { id: "I", name: "I", subscript: "t", x: 380, y: 160, initialValue: 0.01, color: "#ef4444", description: "Infected & infectious individuals" },
      { id: "R", name: "R", subscript: "t", x: 620, y: 160, initialValue: 0.0, color: "#10b981", description: "Recovered / Immune individuals" }
    ],
    links: [
      { id: "birth", fromNodeId: null, toNodeId: "S", rateFormula: "Lambda", rateLatex: "\\Lambda", parameterNames: ["Lambda"] },
      { id: "trans", fromNodeId: "S", toNodeId: "I", rateFormula: "beta * S * I", rateLatex: "\\beta S I", parameterNames: ["beta"] },
      { id: "recov", fromNodeId: "I", toNodeId: "R", rateFormula: "gamma * I", rateLatex: "\\gamma I", parameterNames: ["gamma"] },
      { id: "muS", fromNodeId: "S", toNodeId: null, rateFormula: "mu * S", rateLatex: "\\mu S", parameterNames: ["mu"] },
      { id: "muI", fromNodeId: "I", toNodeId: null, rateFormula: "mu * I", rateLatex: "\\mu I", parameterNames: ["mu"] },
      { id: "muR", fromNodeId: "R", toNodeId: null, rateFormula: "mu * R", rateLatex: "\\mu R", parameterNames: ["mu"] }
    ]
  },
  {
    id: "seir",
    name: "SEIR with Latency Period",
    category: "Epidemiology",
    description: "Epidemic model incorporating exposed latency compartment (E) before infectiousness.",
    nodes: [
      { id: "S", name: "S", x: 100, y: 160, initialValue: 0.99, color: "#3b82f6", description: "Susceptible" },
      { id: "E", name: "E", x: 280, y: 160, initialValue: 0.005, color: "#f59e0b", description: "Exposed / Latent" },
      { id: "I", name: "I", x: 460, y: 160, initialValue: 0.005, color: "#ef4444", description: "Infectious" },
      { id: "R", name: "R", x: 640, y: 160, initialValue: 0.0, color: "#10b981", description: "Recovered" }
    ],
    links: [
      { id: "inf", fromNodeId: null, toNodeId: "S", rateFormula: "Lambda", rateLatex: "\\Lambda", parameterNames: ["Lambda"] },
      { id: "trans", fromNodeId: "S", toNodeId: "E", rateFormula: "beta * S * I", rateLatex: "\\beta S I", parameterNames: ["beta"] },
      { id: "incub", fromNodeId: "E", toNodeId: "I", rateFormula: "sigma * E", rateLatex: "\\sigma E", parameterNames: ["sigma"] },
      { id: "recov", fromNodeId: "I", toNodeId: "R", rateFormula: "gamma * I", rateLatex: "\\gamma I", parameterNames: ["gamma"] },
      { id: "muS", fromNodeId: "S", toNodeId: null, rateFormula: "mu * S", rateLatex: "\\mu S", parameterNames: ["mu"] },
      { id: "muE", fromNodeId: "E", toNodeId: null, rateFormula: "mu * E", rateLatex: "\\mu E", parameterNames: ["mu"] },
      { id: "muI", fromNodeId: "I", toNodeId: null, rateFormula: "mu * I", rateLatex: "\\mu I", parameterNames: ["mu"] },
      { id: "muR", fromNodeId: "R", toNodeId: null, rateFormula: "mu * R", rateLatex: "\\mu R", parameterNames: ["mu"] }
    ]
  },
  {
    id: "lotka_volterra",
    name: "Lotka-Volterra Predator-Prey Interaction",
    category: "Ecology",
    description: "Nonlinear coupled trophic system with prey reproduction, predation predation loss, and predator mortality.",
    nodes: [
      { id: "Prey", name: "x", x: 220, y: 160, initialValue: 2.0, color: "#10b981", description: "Prey biomass / density" },
      { id: "Predator", name: "y", x: 520, y: 160, initialValue: 1.0, color: "#ef4444", description: "Predator population" }
    ],
    links: [
      { id: "prey_grow", fromNodeId: null, toNodeId: "Prey", rateFormula: "alpha * x", rateLatex: "\\alpha x", parameterNames: ["alpha"] },
      { id: "predation", fromNodeId: "Prey", toNodeId: null, rateFormula: "beta * x * y", rateLatex: "\\beta x y", parameterNames: ["beta"] },
      { id: "pred_repr", fromNodeId: null, toNodeId: "Predator", rateFormula: "delta * x * y", rateLatex: "\\delta x y", parameterNames: ["delta"] },
      { id: "pred_mort", fromNodeId: "Predator", toNodeId: null, rateFormula: "gamma * y", rateLatex: "\\gamma y", parameterNames: ["gamma"] }
    ]
  },
  {
    id: "pkpd",
    name: "Two-Compartment Pharmacokinetics (PK)",
    category: "Pharmacology",
    description: "Oral drug absorption with distribution between Central (blood) and Peripheral (tissue) compartments and renal elimination.",
    nodes: [
      { id: "Gut", name: "A_g", x: 120, y: 160, initialValue: 100.0, color: "#8b5cf6", description: "Drug depot in gut" },
      { id: "Central", name: "A_c", x: 380, y: 160, initialValue: 0.0, color: "#3b82f6", description: "Central blood plasma" },
      { id: "Periph", name: "A_p", x: 640, y: 160, initialValue: 0.0, color: "#06b6d4", description: "Peripheral tissue" }
    ],
    links: [
      { id: "abs", fromNodeId: "Gut", toNodeId: "Central", rateFormula: "k_a * A_g", rateLatex: "k_a A_g", parameterNames: ["k_a"] },
      { id: "dist_in", fromNodeId: "Central", toNodeId: "Periph", rateFormula: "k_12 * A_c", rateLatex: "k_{12} A_c", parameterNames: ["k_12"] },
      { id: "dist_out", fromNodeId: "Periph", toNodeId: "Central", rateFormula: "k_21 * A_p", rateLatex: "k_{21} A_p", parameterNames: ["k_21"] },
      { id: "elim", fromNodeId: "Central", toNodeId: null, rateFormula: "k_e * A_c", rateLatex: "k_e A_c", parameterNames: ["k_e"] }
    ]
  },
  {
    id: "brusselator",
    name: "Brusselator Autocatalytic Chemical Oscillator",
    category: "Chemical Kinetics",
    description: "Prigogine-Lefever model exhibiting limit cycle biochemical oscillations and Turing patterns.",
    nodes: [
      { id: "X", name: "X", x: 260, y: 160, initialValue: 1.0, color: "#f97316", description: "Intermediate activator X" },
      { id: "Y", name: "Y", x: 500, y: 160, initialValue: 2.0, color: "#a855f7", description: "Intermediate inhibitor Y" }
    ],
    links: [
      { id: "feed_A", fromNodeId: null, toNodeId: "X", rateFormula: "A", rateLatex: "A", parameterNames: ["A"] },
      { id: "react_B", fromNodeId: "X", toNodeId: "Y", rateFormula: "B * X", rateLatex: "B X", parameterNames: ["B"] },
      { id: "autocatalysis", fromNodeId: "Y", toNodeId: "X", rateFormula: "X^2 * Y", rateLatex: "X^2 Y", parameterNames: ["X", "Y"] },
      { id: "decomp", fromNodeId: "X", toNodeId: null, rateFormula: "X", rateLatex: "X", parameterNames: [] }
    ]
  }
];

interface DiagramStudioProps {
  onSendToSolver?: (problemType: string, customParams?: any) => void;
}

export const DiagramStudio: React.FC<DiagramStudioProps> = ({ onSendToSolver }) => {
  const [nodes, setNodes] = useState<CompartmentNode[]>(PRESET_MODELS[0].nodes);
  const [links, setLinks] = useState<FlowLink[]>(PRESET_MODELS[0].links);
  const [activePreset, setActivePreset] = useState<string>("sir");

  // Selection & dragging state
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedLinkId, setSelectedLinkId] = useState<string | null>(null);
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Creation modes
  const [linkingSourceNodeId, setLinkingSourceNodeId] = useState<string | null>(null);
  const [copiedTikZ, setCopiedTikZ] = useState(false);
  const [copiedLatex, setCopiedLatex] = useState(false);

  const svgRef = useRef<SVGSVGElement | null>(null);

  // Derived Coupled ODE System in LaTeX
  const derivedOdeSystem = useMemo(() => {
    return nodes.map(node => {
      const inflows = links
        .filter(l => l.toNodeId === node.id)
        .map(l => l.rateLatex);
      const outflows = links
        .filter(l => l.fromNodeId === node.id)
        .map(l => l.rateLatex);

      let rhs = "";
      if (inflows.length > 0) {
        rhs += inflows.join(" + ");
      }
      if (outflows.length > 0) {
        if (rhs.length > 0) rhs += " - ";
        rhs += outflows.map(o => (o.includes("+") ? `(${o})` : o)).join(" - ");
      }
      if (rhs.length === 0) rhs = "0";

      return {
        varName: node.name,
        latex: `\\frac{d ${node.name}}{dt} = ${rhs}`,
        initialCondition: `${node.name}(0) = ${node.initialValue}`
      };
    });
  }, [nodes, links]);

  // Handle Dragging
  const handleMouseDownNode = (e: React.MouseEvent, node: CompartmentNode) => {
    e.stopPropagation();
    if (linkingSourceNodeId) {
      // Complete linking
      if (linkingSourceNodeId !== node.id) {
        const fromName = nodes.find(n => n.id === linkingSourceNodeId)?.name || 'X';
        const newLink: FlowLink = {
          id: `link_${Date.now()}`,
          fromNodeId: linkingSourceNodeId,
          toNodeId: node.id,
          rateFormula: `k * ${fromName}`,
          rateLatex: `k \\cdot ${fromName}`,
          parameterNames: ["k"]
        };
        setLinks(prev => [...prev, newLink]);
        setSelectedLinkId(newLink.id);
      }
      setLinkingSourceNodeId(null);
      return;
    }

    setSelectedNodeId(node.id);
    setSelectedLinkId(null);
    setDraggingNodeId(node.id);

    if (svgRef.current) {
      const rect = svgRef.current.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left - node.x,
        y: e.clientY - rect.top - node.y
      });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggingNodeId || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const newX = Math.max(50, Math.min(rect.width - 50, e.clientX - rect.left - dragOffset.x));
    const newY = Math.max(50, Math.min(rect.height - 50, e.clientY - rect.top - dragOffset.y));

    setNodes(prev =>
      prev.map(n => (n.id === draggingNodeId ? { ...n, x: Math.round(newX), y: Math.round(newY) } : n))
    );
  };

  const handleMouseUp = () => {
    setDraggingNodeId(null);
  };

  // Add new compartment node
  const handleAddNode = () => {
    const letters = ["X", "Y", "Z", "W", "A", "B", "C"];
    const used = new Set(nodes.map(n => n.name));
    const nextName = letters.find(l => !used.has(l)) || `V_${nodes.length + 1}`;
    const colors = ["#3b82f6", "#10b981", "#ef4444", "#f59e0b", "#8b5cf6", "#06b6d4", "#ec4899"];
    const newNode: CompartmentNode = {
      id: `node_${Date.now()}`,
      name: nextName,
      x: 100 + (nodes.length * 90) % 500,
      y: 180 + ((nodes.length * 30) % 100),
      initialValue: 1.0,
      color: colors[nodes.length % colors.length],
      description: `State compartment ${nextName}`
    };
    setNodes(prev => [...prev, newNode]);
    setSelectedNodeId(newNode.id);
  };

  // Delete node
  const handleDeleteNode = (id: string) => {
    setNodes(prev => prev.filter(n => n.id !== id));
    setLinks(prev => prev.filter(l => l.fromNodeId !== id && l.toNodeId !== id));
    if (selectedNodeId === id) setSelectedNodeId(null);
  };

  // Delete link
  const handleDeleteLink = (id: string) => {
    setLinks(prev => prev.filter(l => l.id !== id));
    if (selectedLinkId === id) setSelectedLinkId(null);
  };

  // Load Preset
  const handleLoadPreset = (presetId: string) => {
    const preset = PRESET_MODELS.find(p => p.id === presetId);
    if (!preset) return;
    setActivePreset(presetId);
    setNodes(JSON.parse(JSON.stringify(preset.nodes)));
    setLinks(JSON.parse(JSON.stringify(preset.links)));
    setSelectedNodeId(null);
    setSelectedLinkId(null);
    setLinkingSourceNodeId(null);
  };

  // Generate TikZ Code for LaTeX publications
  const tikzCode = useMemo(() => {
    let code = `\\documentclass{standalone}\n\\usepackage{tikz}\n\\usetikzlibrary{arrows.meta, positioning, shapes.geometric}\n\\begin{document}\n\\begin{tikzpicture}[\n  compartment/.style={rectangle, rounded corners=6pt, minimum width=2.2cm, minimum height=1.4cm, text centered, draw=black!70, line width=1.2pt, fill=blue!10, font=\\Large\\bfseries},\n  rate/.style={-{Stealth[length=3mm, width=2.5mm]}, line width=1.3pt, draw=black!80},\n  rate_label/.style={midway, above, font=\\normalsize\\itshape}\n]\n\n`;

    // Nodes
    nodes.forEach(node => {
      const tikzX = (node.x / 80).toFixed(2);
      const tikzY = (-node.y / 80).toFixed(2);
      code += `  \\node[compartment] (${node.id}) at (${tikzX}, ${tikzY}) {$${node.name}$};\n`;
    });
    code += `\n`;

    // Links
    links.forEach(link => {
      if (link.fromNodeId && link.toNodeId) {
        code += `  \\draw[rate] (${link.fromNodeId}) -- node[rate_label] {$${link.rateLatex}$} (${link.toNodeId});\n`;
      } else if (!link.fromNodeId && link.toNodeId) {
        code += `  \\draw[rate] ([xshift=-1.4cm]${link.toNodeId}.west) -- node[rate_label] {$${link.rateLatex}$} (${link.toNodeId});\n`;
      } else if (link.fromNodeId && !link.toNodeId) {
        code += `  \\draw[rate] (${link.fromNodeId}) -- node[rate_label] {$${link.rateLatex}$} ([yshift=-1.4cm]${link.fromNodeId}.south);\n`;
      }
    });

    code += `\\end{tikzpicture}\n\\end{document}`;
    return code;
  }, [nodes, links]);

  // Export SVG to download
  const handleExportSvg = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const source = serializer.serializeToString(svgRef.current);
    const blob = new Blob([source], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const downloadLink = document.createElement("a");
    downloadLink.href = url;
    downloadLink.download = `${activePreset || 'compartmental'}_schematic.svg`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  const selectedNode = nodes.find(n => n.id === selectedNodeId);
  const selectedLink = links.find(l => l.id === selectedLinkId);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Visual Modeler & Schematic Studio
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Auto-Coupled ODE Extraction
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                LaTeX TikZ Export
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Compartmental Flow & Schematic Diagram Studio
            </h2>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Design multi-compartment dynamical systems, pharmacokinetic networks, predator-prey trophic webs, and chemical reaction topologies. 
              The engine automatically formulates governing coupled differential equations in real-time, extracts conservation laws, and exports publication-ready TikZ & vector graphics.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                if (onSendToSolver) {
                  onSendToSolver(
                    activePreset === "lotka_volterra" ? "coupled_predator_prey" : "compartmental_sir",
                    { nodes, links }
                  );
                }
              }}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-medium rounded-xl shadow-lg shadow-indigo-500/20 transition-all text-sm"
            >
              <Zap className="w-4 h-4 text-cyan-200" />
              Solve Step-by-Step
            </button>
            <button
              onClick={handleExportSvg}
              className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl transition-all text-sm"
            >
              <Download className="w-4 h-4 text-slate-300" />
              Export SVG
            </button>
          </div>
        </div>
      </div>

      {/* Preset Selector Tabs */}
      <div className="flex flex-wrap gap-2 items-center p-2 bg-slate-900/80 border border-slate-800 rounded-xl">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2">Presets:</span>
        {PRESET_MODELS.map(preset => (
          <button
            key={preset.id}
            onClick={() => handleLoadPreset(preset.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activePreset === preset.id
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "bg-slate-800/80 text-slate-300 hover:bg-slate-700/80"
            }`}
          >
            {preset.name}
          </button>
        ))}
      </div>

      {/* Main Canvas and Side Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual Canvas Area */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col shadow-xl">
          {/* Canvas Toolbar */}
          <div className="flex items-center justify-between px-4 py-3 bg-slate-800/80 border-b border-slate-700/60 text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={handleAddNode}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Compartment
              </button>
              <button
                onClick={() => {
                  if (selectedNodeId) {
                    setLinkingSourceNodeId(selectedNodeId);
                  }
                }}
                disabled={!selectedNodeId}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  selectedNodeId
                    ? "bg-cyan-600 hover:bg-cyan-500 text-white"
                    : "bg-slate-800 text-slate-500 cursor-not-allowed"
                }`}
              >
                <ArrowRight className="w-3.5 h-3.5" />
                Connect Rate
              </button>
              {linkingSourceNodeId && (
                <span className="px-2 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded text-xs animate-pulse">
                  Click destination compartment...
                </span>
              )}
            </div>

            <div className="flex items-center gap-3 text-slate-400">
              <span>{nodes.length} Compartments</span>
              <span>•</span>
              <span>{links.length} Rate Transitions</span>
            </div>
          </div>

          {/* Interactive SVG Canvas */}
          <div className="relative bg-slate-950/70 min-h-[460px] flex-1 select-none overflow-hidden cursor-crosshair">
            <svg
              ref={svgRef}
              className="w-full h-full min-h-[460px]"
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onClick={() => {
                setSelectedNodeId(null);
                setSelectedLinkId(null);
                setLinkingSourceNodeId(null);
              }}
            >
              <defs>
                <marker
                  id="arrow"
                  viewBox="0 0 10 10"
                  refX="10"
                  refY="5"
                  markerWidth="7"
                  markerHeight="7"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#94a3b8" />
                </marker>
                <marker
                  id="arrow-selected"
                  viewBox="0 0 10 10"
                  refX="10"
                  refY="5"
                  markerWidth="8"
                  markerHeight="8"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#38bdf8" />
                </marker>
                {/* Background grid pattern */}
                <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(255, 255, 255, 0.04)" strokeWidth="1" />
                </pattern>
              </defs>

              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Render Rate Flow Links */}
              {links.map(link => {
                const fromNode = nodes.find(n => n.id === link.fromNodeId);
                const toNode = nodes.find(n => n.id === link.toNodeId);
                const isSelected = selectedLinkId === link.id;

                let startX = 0, startY = 0, endX = 0, endY = 0;
                let midX = 0, midY = 0;

                if (fromNode && toNode) {
                  // Link between two nodes
                  startX = fromNode.x;
                  startY = fromNode.y;
                  endX = toNode.x;
                  endY = toNode.y;

                  // Direction vector
                  const dx = endX - startX;
                  const dy = endY - startY;
                  const dist = Math.sqrt(dx * dx + dy * dy) || 1;
                  const offset = 46;

                  startX += (dx / dist) * offset;
                  startY += (dy / dist) * offset;
                  endX -= (dx / dist) * (offset + 10);
                  endY -= (dy / dist) * (offset + 10);

                  midX = (startX + endX) / 2;
                  midY = (startY + endY) / 2 - 14;
                } else if (!fromNode && toNode) {
                  // Inflow from source
                  endX = toNode.x - 48;
                  endY = toNode.y;
                  startX = endX - 60;
                  startY = endY;
                  midX = (startX + endX) / 2;
                  midY = startY - 14;
                } else if (fromNode && !toNode) {
                  // Outflow to sink
                  startX = fromNode.x;
                  startY = fromNode.y + 44;
                  endX = startX;
                  endY = startY + 50;
                  midX = startX + 18;
                  midY = (startY + endY) / 2;
                }

                return (
                  <g
                    key={link.id}
                    onClick={e => {
                      e.stopPropagation();
                      setSelectedLinkId(link.id);
                      setSelectedNodeId(null);
                    }}
                    className="cursor-pointer group"
                  >
                    <line
                      x1={startX}
                      y1={startY}
                      x2={endX}
                      y2={endY}
                      stroke={isSelected ? "#38bdf8" : "#64748b"}
                      strokeWidth={isSelected ? 3 : 2}
                      markerEnd={isSelected ? "url(#arrow-selected)" : "url(#arrow)"}
                      className="transition-all group-hover:stroke-cyan-400"
                    />
                    {/* Rate formula label background pill */}
                    <rect
                      x={midX - 28}
                      y={midY - 10}
                      width="56"
                      height="20"
                      rx="6"
                      fill="#0f172a"
                      stroke={isSelected ? "#38bdf8" : "#334155"}
                      strokeWidth="1"
                    />
                    <text
                      x={midX}
                      y={midY + 4}
                      textAnchor="middle"
                      fill={isSelected ? "#38bdf8" : "#cbd5e1"}
                      fontSize="11"
                      fontWeight="600"
                      className="font-mono select-none"
                    >
                      {link.rateFormula}
                    </text>
                  </g>
                );
              })}

              {/* Render Compartment Nodes */}
              {nodes.map(node => {
                const isSelected = selectedNodeId === node.id;
                const isLinkingSource = linkingSourceNodeId === node.id;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    onMouseDown={e => handleMouseDownNode(e, node)}
                    className="cursor-move group"
                  >
                    {/* Glowing ring if selected or linking */}
                    {(isSelected || isLinkingSource) && (
                      <circle
                        r="48"
                        fill="none"
                        stroke={isLinkingSource ? "#f59e0b" : "#38bdf8"}
                        strokeWidth="2"
                        strokeDasharray={isLinkingSource ? "4 4" : "none"}
                        className="animate-pulse"
                      />
                    )}

                    {/* Compartment Box / Circle */}
                    <rect
                      x="-42"
                      y="-34"
                      width="84"
                      height="68"
                      rx="14"
                      fill="#1e293b"
                      stroke={isSelected ? "#38bdf8" : node.color}
                      strokeWidth={isSelected ? "3" : "2"}
                      className="shadow-xl drop-shadow transition-all group-hover:fill-slate-800"
                    />

                    {/* Node Label */}
                    <text
                      y="-4"
                      textAnchor="middle"
                      fill="#f8fafc"
                      fontSize="18"
                      fontWeight="bold"
                      className="font-serif select-none pointer-events-none"
                    >
                      {node.name}
                    </text>

                    {/* Initial Value */}
                    <text
                      y="16"
                      textAnchor="middle"
                      fill="#94a3b8"
                      fontSize="10"
                      className="font-mono select-none pointer-events-none"
                    >
                      IC: {node.initialValue}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Right Side: Inspector & Auto-Derived Coupled System */}
        <div className="space-y-6">
          {/* Node / Link Inspector */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-400" />
                Component Inspector
              </span>
              {selectedNode && (
                <button
                  onClick={() => handleDeleteNode(selectedNode.id)}
                  className="text-red-400 hover:text-red-300 text-xs flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              )}
              {selectedLink && (
                <button
                  onClick={() => handleDeleteLink(selectedLink.id)}
                  className="text-red-400 hover:text-red-300 text-xs flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              )}
            </h3>

            {selectedNode ? (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">State Variable Name</label>
                  <input
                    type="text"
                    value={selectedNode.name}
                    onChange={e => {
                      const val = e.target.value;
                      setNodes(prev => prev.map(n => n.id === selectedNode.id ? { ...n, name: val } : n));
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Initial Condition (t = 0)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={selectedNode.initialValue}
                    onChange={e => {
                      const val = parseFloat(e.target.value) || 0;
                      setNodes(prev => prev.map(n => n.id === selectedNode.id ? { ...n, initialValue: val } : n));
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Theme Accent Color</label>
                  <div className="flex gap-2">
                    {["#3b82f6", "#10b981", "#ef4444", "#f59e0b", "#8b5cf6", "#06b6d4"].map(c => (
                      <button
                        key={c}
                        onClick={() => setNodes(prev => prev.map(n => n.id === selectedNode.id ? { ...n, color: c } : n))}
                        className={`w-6 h-6 rounded-full border-2 ${selectedNode.color === c ? 'border-white scale-110' : 'border-transparent'}`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            ) : selectedLink ? (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Rate Law Expression</label>
                  <input
                    type="text"
                    value={selectedLink.rateFormula}
                    onChange={e => {
                      const val = e.target.value;
                      setLinks(prev => prev.map(l => l.id === selectedLink.id ? { ...l, rateFormula: val, rateLatex: val } : l));
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                  />
                </div>
                <div className="p-2.5 bg-slate-800/80 rounded-lg">
                  <span className="text-slate-400 block mb-1">Rendered Rate Law:</span>
                  <MathView math={selectedLink.rateLatex} />
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic py-4 text-center">
                Click any compartment node or rate arrow on the canvas to inspect and edit its parameters.
              </p>
            )}
          </div>

          {/* Auto-Derived Coupled Differential Equations */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                Live Coupled ODE System
              </h3>
              <button
                onClick={() => {
                  const allLatex = derivedOdeSystem.map(eq => eq.latex).join("\n");
                  navigator.clipboard.writeText(allLatex);
                  setCopiedLatex(true);
                  setTimeout(() => setCopiedLatex(false), 2000);
                }}
                className="text-slate-400 hover:text-white text-xs flex items-center gap-1"
              >
                {copiedLatex ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedLatex ? "Copied" : "Copy LaTeX"}
              </button>
            </div>

            <div className="space-y-3 bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
              {derivedOdeSystem.map((eq, i) => (
                <div key={i} className="pb-2 border-b border-slate-800/60 last:border-0 last:pb-0">
                  <MathView math={eq.latex} displayMode={true} />
                  <div className="text-[10px] text-slate-400 font-mono mt-1 text-right">
                    {eq.initialCondition}
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                if (onSendToSolver) {
                  onSendToSolver(
                    activePreset === "lotka_volterra" ? "coupled_predator_prey" : "compartmental_sir",
                    { nodes, links }
                  );
                }
              }}
              className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-medium rounded-xl text-xs shadow-lg shadow-emerald-500/20 transition-all"
            >
              <Zap className="w-3.5 h-3.5" />
              Transfer System to Step-by-Step Solver
            </button>
          </div>
        </div>
      </div>

      {/* LaTeX TikZ Code Generator Drawer */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <FileCode className="w-5 h-5 text-indigo-400" />
              LaTeX TikZ Publication Export
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Copy-paste directly into your Overleaf or LaTeX document for vector graphics rendering.
            </p>
          </div>
          <button
            onClick={() => {
              navigator.clipboard.writeText(tikzCode);
              setCopiedTikZ(true);
              setTimeout(() => setCopiedTikZ(false), 2000);
            }}
            className="flex items-center gap-2 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition-colors"
          >
            {copiedTikZ ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedTikZ ? "Copied TikZ Code" : "Copy TikZ Code"}
          </button>
        </div>

        <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-indigo-300 overflow-x-auto max-h-60 leading-relaxed">
          {tikzCode}
        </pre>
      </div>
    </div>
  );
};
